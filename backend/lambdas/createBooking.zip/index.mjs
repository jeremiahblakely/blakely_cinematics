import { DynamoDBClient, PutItemCommand } from "@aws-sdk/client-dynamodb";
import { v4 as uuid } from "uuid";

const ddb = new DynamoDBClient({});

const ok = (body) => ({
  statusCode: 200,
  headers: {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
  },
  body: JSON.stringify(body),
});

const bad = (code, message) => ({
  statusCode: code,
  headers: {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
  },
  body: JSON.stringify({ error: message }),
});

export const handler = async (event) => {
  try {
    const data = event?.body ? JSON.parse(event.body) : {};
    // expected: { name, email, date, time, phone?, notes? }
    const required = ["name", "email", "date", "time"];
    for (const k of required) {
      if (!data[k]) return bad(400, `Missing: ${k}`);
    }

    const bookingId = uuid();
    const now = new Date().toISOString();

    const item = {
      bookingId: { S: bookingId },
      name:      { S: String(data.name) },
      email:     { S: String(data.email) },
      phone:     { S: String(data.phone || "") },
      date:      { S: String(data.date) },
      time:      { S: String(data.time) },
      notes:     { S: String(data.notes || "") },
      createdAt: { S: now },
      status:    { S: "NEW" },
    };

    await ddb.send(new PutItemCommand({
      TableName: process.env.TABLE_BOOKINGS,
      Item: item
    }));

    return ok({ bookingId, status: "NEW", createdAt: now });
  } catch (e) {
    console.error(e);
    return bad(500, "Internal error");
  }
};
